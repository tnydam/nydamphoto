NYDAM PHOTOGRAPHY — PHASE 1 DEPLOY PACKAGE
==========================================

WHAT THIS IS
------------
The homepage plus its small connected pages, ready for GitHub Pages.
Big service clusters (weddings, seniors, etc.) are NOT included yet —
links to them gracefully land on 404.html until those pages are built.

PAGES INCLUDED (clean URLs)
---------------------------
/              index.html              Homepage
/about/        about/index.html        About — Arlen & Tanya, story, philosophy
/book/         book/index.html         Booking hub (all 9 services -> live Calendly)
/referrals/    referrals/index.html    Referral program
/reviews/      reviews/index.html      Client reviews (3 real testimonials)
404.html       Graceful "page not ready" fallback
CNAME          Custom domain (nydamphoto.com)
.nojekyll      Tells GitHub Pages to serve folders as-is

HOW TO DEPLOY
-------------
1. Upload the CONTENTS of this folder to the ROOT of your GitHub Pages repo
   (so index.html sits at the repo root, with about/ book/ etc. beside it).
2. Commit. GitHub Pages will publish within a minute or two.
3. Confirm your repo Settings > Pages is set to the correct branch and that
   the custom domain nydamphoto.com is connected (the CNAME file handles this).

IMAGE FILES YOU STILL NEED TO ADD (upload to repo ROOT)
-------------------------------------------------------
Homepage:
  austin-wedding-photographer-hero.jpg   (wide hero background, ~2000px)
  austin-wedding-photography.jpg
  austin-senior-portraits.jpg
  austin-engagement-photography.jpg
  austin-family-photography.jpg
  austin-quinceanera-photography.jpg
  austin-catholic-photography.jpg
  austin-corporate-branding.jpg
  austin-sports-photography.jpg
  austin-event-photography.jpg
  austin-wedding-feature.jpg
  austin-senior-feature.jpg
  story-eberly-austin.jpg
  story-brynley-senior.jpg
About:
  arlen-nydam-austin-photographer.jpg
  tanya-nydam-austin-photographer.jpg
Shared (link previews + schema):
  og-nydam-photography.jpg   (~1200x630)
  logo.png

Until added, image areas show your dark/cream brand color (no broken icons).
All image paths are root-relative (start with /), so they work from every page.

LINKS THAT WILL 404 UNTIL BUILT (Phase 2 — service clusters & hubs)
-------------------------------------------------------------------
/weddings/  /seniors/  /seniors/program/  /engagements/  /families/
/quinceanera/  /sacraments/  /corporate/  /sports/  /events/
/portfolio/  /portfolio/stories/...  /venues/  /guides/
These are intentionally not in this phase. The booking buttons still work
(they go straight to Calendly), and 404.html keeps any stray click graceful.

NOTES
-----
- Booking buttons link directly to your live Calendly events.
- "Meet Nydam Photography" -> calendly.com/nydamphotography/photo-event
- Contact form posts to Formspree (f/xlgpokwb) — confirm that's the inbox you want.
- Facebook is set to facebook.com/nydamphoto (corrected).
- No stock images anywhere. No "free/buy/gift" language. Fully insured stated.
